# SolarTime — Native Android App (with 10-Min Pre-Event Alarm & Cloud APK Builder)

A standalone Kotlin + Jetpack Compose Android app that calculates sunrise, sunset, solar noon, civil twilight, live 1-second countdown, and schedules native Android `AlarmManager` notifications (default **10 minutes before** sunrise/sunset, with automatic re-arming after reboot).

## Easiest Way to Get the Installable `.apk` (No Android Studio Needed)
1. Unzip `SunriseSunsetApp.zip` and upload the contents of `SunriseSunsetApp/` (including the `.github/workflows/build-apk.yml` file) to a free GitHub repository.
2. Open the **Actions** tab in GitHub — the **Build SolarTime Android APK** workflow runs automatically (or click **Run workflow**).
3. Download **`SolarTime-APK`** from the finished workflow's **Artifacts** section, extract `app-debug.apk`, and install it directly on your Android phone.

## Or Build Locally in Android Studio
1. Unzip `SunriseSunsetApp.zip` and open `SunriseSunsetApp` in Android Studio (JDK 17, Android SDK 35).
2. Click **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
3. Install `app/build/outputs/apk/debug/app-debug.apk` on any Android 8.0+ device.
