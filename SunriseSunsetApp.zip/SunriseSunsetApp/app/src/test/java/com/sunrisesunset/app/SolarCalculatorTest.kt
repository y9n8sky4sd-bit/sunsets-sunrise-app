package com.sunrisesunset.app

import com.sunrisesunset.app.domain.SolarCalculator
import com.sunrisesunset.app.model.AlarmConfig
import com.sunrisesunset.app.model.AlarmTarget
import com.sunrisesunset.app.model.LocationConfig
import com.sunrisesunset.app.model.SolarEventType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Duration
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

class SolarCalculatorTest {

    @Test
    fun chalisgaonNov19HasExpectedSunriseAndSunset() {
        val zone = ZoneId.of("Asia/Kolkata")
        val times = SolarCalculator.calculateForDate(
            date = LocalDate.of(2026, 11, 19),
            latitude = 20.4640,
            longitude = 75.0061,
            zoneId = zone
        )
        assertNotNull(times.sunrise)
        assertNotNull(times.sunset)
        assertEquals(6, times.sunrise!!.hour)
        assertTrue(times.sunrise!!.minute in 38..48)
        assertEquals(17, times.sunset!!.hour)
        assertTrue(times.sunset!!.minute in 48..58)
    }

    @Test
    fun preEventAlarmSchedulesTenMinutesBeforeNextEvent() {
        val location = LocationConfig("Chalisgaon, India", 20.4640, 75.0061, "Asia/Kolkata")
        val zone = location.safeZoneId()
        val midday = ZonedDateTime.of(2026, 11, 19, 12, 0, 0, 0, zone)
        val alarm = SolarCalculator.calculateNextAlarm(
            now = midday,
            location = location,
            alarmConfig = AlarmConfig(enabled = true, leadMinutes = 10, target = AlarmTarget.BOTH)
        )
        assertNotNull(alarm)
        assertEquals(SolarEventType.SUNSET, alarm!!.eventType)
        assertEquals(10L, Duration.between(alarm.triggerTime, alarm.eventTime).toMinutes())
    }
}
