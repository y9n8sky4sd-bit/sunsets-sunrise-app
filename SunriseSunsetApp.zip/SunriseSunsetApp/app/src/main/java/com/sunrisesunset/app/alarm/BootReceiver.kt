package com.sunrisesunset.app.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.sunrisesunset.app.data.LocationPreferences

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val prefs = LocationPreferences(context)
            AlarmScheduler.syncAlarm(
                context = context,
                location = prefs.loadLocation(),
                alarmConfig = prefs.loadAlarmConfig(),
                use24Hour = prefs.loadUse24HourFormat()
            )
        }
    }
}
