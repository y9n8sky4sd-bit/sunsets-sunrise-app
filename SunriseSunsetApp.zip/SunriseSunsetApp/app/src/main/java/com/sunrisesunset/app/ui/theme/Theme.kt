package com.sunrisesunset.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFFFB74D),
    onPrimary = Color(0xFF2B1700),
    secondary = Color(0xFF81D4FA),
    background = Color(0xFF0E1420),
    surface = Color(0xFF172030),
    onBackground = Color(0xFFF3F6FA),
    onSurface = Color(0xFFF3F6FA)
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFFE65100),
    onPrimary = Color.White,
    secondary = Color(0xFF0277BD),
    background = Color(0xFFF6F8FC),
    surface = Color.White,
    onBackground = Color(0xFF141B29),
    onSurface = Color(0xFF141B29)
)

@Composable
fun SolarTimeTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
