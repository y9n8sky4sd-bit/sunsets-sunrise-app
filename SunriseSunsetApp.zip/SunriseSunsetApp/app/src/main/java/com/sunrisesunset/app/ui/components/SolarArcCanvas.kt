package com.sunrisesunset.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SolarArcCanvas(
    daylightProgress: Float?,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(120.dp)
    ) {
        val horizontalPadding = 28.dp.toPx()
        val arcWidth = size.width - horizontalPadding * 2
        val arcRadius = arcWidth / 2f
        val baselineY = size.height - 16.dp.toPx()
        val centerX = size.width / 2f

        drawLine(
            color = Color.White.copy(alpha = 0.30f),
            start = Offset(horizontalPadding - 10f, baselineY),
            end = Offset(size.width - horizontalPadding + 10f, baselineY),
            strokeWidth = 2.dp.toPx()
        )

        val topLeft = Offset(horizontalPadding, baselineY - arcRadius)
        val arcSize = Size(arcWidth, arcWidth)
        drawArc(
            color = Color.White.copy(alpha = 0.35f),
            startAngle = 180f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = topLeft,
            size = arcSize,
            style = Stroke(
                width = 3.dp.toPx(),
                cap = StrokeCap.Round,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 10f))
            )
        )

        if (daylightProgress != null) {
            val clamped = daylightProgress.coerceIn(0f, 1f)
            drawArc(
                color = Color(0xFFFFD54F),
                startAngle = 180f,
                sweepAngle = 180f * clamped,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
            )

            val angleRad = PI * (1.0 - clamped)
            val sunX = centerX + (arcRadius * cos(angleRad)).toFloat()
            val sunY = baselineY - (arcRadius * sin(angleRad)).toFloat()

            drawCircle(
                color = Color(0xFFFFE082).copy(alpha = 0.35f),
                radius = 16.dp.toPx(),
                center = Offset(sunX, sunY)
            )
            drawCircle(
                color = Color(0xFFFFD54F),
                radius = 8.dp.toPx(),
                center = Offset(sunX, sunY)
            )
        }
    }
}
