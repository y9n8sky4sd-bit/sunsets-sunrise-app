package com.sunrisesunset.app.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.sunrisesunset.app.domain.SolarCalculator
import com.sunrisesunset.app.model.AlarmConfig
import com.sunrisesunset.app.model.LocationConfig
import com.sunrisesunset.app.model.ScheduledSolarAlarm
import com.sunrisesunset.app.model.SolarEventType
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

object AlarmScheduler {

    private const val REQUEST_CODE_PRE_ALARM = 1001
    private const val REQUEST_CODE_EXACT_CHIME = 1002

    fun syncAlarm(
        context: Context,
        location: LocationConfig,
        alarmConfig: AlarmConfig,
        use24Hour: Boolean
    ): ScheduledSolarAlarm? {
        val now = ZonedDateTime.now(location.safeZoneId())
        val formatter = DateTimeFormatter.ofPattern(if (use24Hour) "HH:mm" else "hh:mm a")

        // 1. Pre-event alarm (e.g. 10 minutes before)
        val nextPre = if (alarmConfig.enabled) {
            SolarCalculator.calculateNextAlarm(now, location, alarmConfig)
        } else {
            null
        }
        if (nextPre != null) {
            val eventName = if (nextPre.eventType == SolarEventType.SUNRISE) "Sunrise" else "Sunset"
            scheduleOne(
                context = context,
                requestCode = REQUEST_CODE_PRE_ALARM,
                triggerMillis = nextPre.triggerTime.toInstant().toEpochMilli(),
                title = "$eventName in ${alarmConfig.leadMinutes} minutes",
                body = "$eventName at ${nextPre.eventTime.format(formatter)} in ${location.name}",
                isExactChime = false,
                eventType = nextPre.eventType
            )
        } else {
            cancelByCode(context, REQUEST_CODE_PRE_ALARM)
        }

        // 2. Exact-time Sunrise / Sunset chime tune (0 minutes before)
        if (alarmConfig.exactChimeEnabled) {
            val nextCountdown = SolarCalculator.calculateCountdown(now, location)
            if (nextCountdown != null) {
                val eventName = if (nextCountdown.nextEvent == SolarEventType.SUNRISE) "Sunrise" else "Sunset"
                scheduleOne(
                    context = context,
                    requestCode = REQUEST_CODE_EXACT_CHIME,
                    triggerMillis = nextCountdown.targetTime.toInstant().toEpochMilli(),
                    title = "$eventName Now",
                    body = "Exact $eventName time (${nextCountdown.targetTime.format(formatter)}) in ${location.name}",
                    isExactChime = true,
                    eventType = nextCountdown.nextEvent
                )
            } else {
                cancelByCode(context, REQUEST_CODE_EXACT_CHIME)
            }
        } else {
            cancelByCode(context, REQUEST_CODE_EXACT_CHIME)
        }

        return nextPre
    }

    private fun scheduleOne(
        context: Context,
        requestCode: Int,
        triggerMillis: Long,
        title: String,
        body: String,
        isExactChime: Boolean,
        eventType: SolarEventType
    ) {
        val intent = Intent(context, SolarAlarmReceiver::class.java).apply {
            putExtra(SolarAlarmReceiver.EXTRA_TITLE, title)
            putExtra(SolarAlarmReceiver.EXTRA_BODY, body)
            putExtra(SolarAlarmReceiver.EXTRA_IS_EXACT_CHIME, isExactChime)
            putExtra(SolarAlarmReceiver.EXTRA_EVENT_TYPE, eventType.name)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val canUseExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }

        if (canUseExact) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent)
        } else {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent)
        }
    }

    private fun cancelByCode(context: Context, requestCode: Int) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, SolarAlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }

    fun sendTestAlarm(context: Context, location: LocationConfig, leadMinutes: Int) {
        SolarAlarmReceiver.showNotification(
            context = context,
            title = "Test Solar Alarm ($leadMinutes min before)",
            body = "Notifications and alarm sound are active for ${location.name}."
        )
    }
}
