package com.sunrisesunset.app.model

import java.time.Duration
import java.time.ZonedDateTime

enum class SolarEventType {
    SUNRISE,
    SUNSET
}

enum class AlarmTarget {
    BOTH,
    SUNRISE,
    SUNSET
}

data class AlarmConfig(
    val enabled: Boolean = false,
    val leadMinutes: Int = 10,
    val target: AlarmTarget = AlarmTarget.BOTH,
    val exactChimeEnabled: Boolean = true
)

data class ScheduledSolarAlarm(
    val eventType: SolarEventType,
    val eventTime: ZonedDateTime,
    val triggerTime: ZonedDateTime
)

enum class DayPhase {
    NIGHT,
    DAWN,
    MORNING,
    AFTERNOON,
    GOLDEN_HOUR,
    DUSK
}

data class DailySolarTimes(
    val sunrise: ZonedDateTime?,
    val sunset: ZonedDateTime?,
    val solarNoon: ZonedDateTime,
    val civilDawn: ZonedDateTime?,
    val civilDusk: ZonedDateTime?,
    val daylightDuration: Duration?,
    val isPolarDay: Boolean = false,
    val isPolarNight: Boolean = false
)

data class SolarCountdown(
    val nextEvent: SolarEventType,
    val targetTime: ZonedDateTime,
    val remaining: Duration
) {
    val hours: Long get() = remaining.toHours()
    val minutes: Long get() = (remaining.seconds % 3600) / 60
    val seconds: Long get() = remaining.seconds % 60

    fun formattedHms(): String = String.format("%02d:%02d:%02d", hours, minutes, seconds)
}
