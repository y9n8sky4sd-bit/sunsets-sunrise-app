package com.sunrisesunset.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sunrisesunset.app.ui.HomeScreen
import com.sunrisesunset.app.ui.MainViewModel
import com.sunrisesunset.app.ui.SettingsScreen
import com.sunrisesunset.app.ui.theme.SolarTimeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SolarTimeTheme {
                val viewModel: MainViewModel = viewModel()
                val uiState by viewModel.uiState.collectAsState()
                var showSettings by rememberSaveable { mutableStateOf(false) }

                if (showSettings) {
                    SettingsScreen(
                        currentLocation = uiState.location,
                        use24HourFormat = uiState.use24HourFormat,
                        alarmConfig = uiState.alarmConfig,
                        onSaveLocation = { viewModel.updateLocation(it) },
                        onToggle24Hour = { viewModel.updateTimeFormat(it) },
                        onUpdateAlarm = { viewModel.updateAlarmConfig(it) },
                        onTestAlarm = { viewModel.sendTestAlarm() },
                        onNavigateBack = { showSettings = false }
                    )
                } else {
                    HomeScreen(
                        state = uiState,
                        onToggleAlarm = { enabled ->
                            viewModel.updateAlarmConfig(uiState.alarmConfig.copy(enabled = enabled))
                        },
                        onTestAlarm = { viewModel.sendTestAlarm() },
                        onOpenSettings = { showSettings = true }
                    )
                }
            }
        }
    }
}
