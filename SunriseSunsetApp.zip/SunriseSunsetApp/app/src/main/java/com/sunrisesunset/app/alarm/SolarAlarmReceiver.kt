package com.sunrisesunset.app.alarm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import androidx.core.app.NotificationCompat
import com.sunrisesunset.app.MainActivity
import com.sunrisesunset.app.data.LocationPreferences

class SolarAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra(EXTRA_TITLE) ?: "SolarTime Alarm"
        val body = intent.getStringExtra(EXTRA_BODY) ?: "Upcoming sunrise or sunset reminder."
        val isExactChime = intent.getBooleanExtra(EXTRA_IS_EXACT_CHIME, false)
        val eventType = intent.getStringExtra(EXTRA_EVENT_TYPE) ?: "SUNRISE"

        if (isExactChime) {
            if (eventType == "SUNRISE") SolarChimePlayer.playSunriseTune() else SolarChimePlayer.playSunsetTune()
        }
        showNotification(context, title, body)

        // Automatically schedule the next upcoming alarm
        val prefs = LocationPreferences(context)
        AlarmScheduler.syncAlarm(
            context = context,
            location = prefs.loadLocation(),
            alarmConfig = prefs.loadAlarmConfig(),
            use24Hour = prefs.loadUse24HourFormat()
        )
    }

    companion object {
        const val EXTRA_TITLE = "extra_alarm_title"
        const val EXTRA_BODY = "extra_alarm_body"
        const val EXTRA_IS_EXACT_CHIME = "extra_is_exact_chime"
        const val EXTRA_EVENT_TYPE = "extra_event_type"
        private const val CHANNEL_ID = "solar_time_alarm_channel"
        private const val NOTIFICATION_ID = 2001

        fun showNotification(context: Context, title: String, body: String) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

            val audioAttrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()

            val channel = NotificationChannel(
                CHANNEL_ID,
                "Sunrise & Sunset Alarms",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts before sunrise and sunset"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 300, 150, 300, 150, 400)
                setSound(alarmSound, audioAttrs)
            }
            manager.createNotificationChannel(channel)

            val openIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val contentPendingIntent = PendingIntent.getActivity(
                context,
                0,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText(body)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setSound(alarmSound)
                .setVibrate(longArrayOf(0, 300, 150, 300, 150, 400))
                .setContentIntent(contentPendingIntent)
                .build()

            manager.notify(NOTIFICATION_ID, notification)
        }
    }
}
