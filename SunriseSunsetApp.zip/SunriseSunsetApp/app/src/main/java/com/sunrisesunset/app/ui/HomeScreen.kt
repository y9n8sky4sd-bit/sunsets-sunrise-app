package com.sunrisesunset.app.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Alarm
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.NightsStay
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material.icons.outlined.WbTwilight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sunrisesunset.app.model.AlarmConfig
import com.sunrisesunset.app.model.DayPhase
import com.sunrisesunset.app.model.SolarEventType
import com.sunrisesunset.app.ui.components.SolarArcCanvas
import java.time.Duration
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    state: SolarUiState,
    onToggleAlarm: (Boolean) -> Unit,
    onTestAlarm: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val timeFormatter = DateTimeFormatter.ofPattern(if (state.use24HourFormat) "HH:mm" else "hh:mm a")
    val dateFormatter = DateTimeFormatter.ofPattern("EEEE, MMM d, yyyy")
    val gradientColors = phaseGradient(state.dayPhase)

    val notifPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        onToggleAlarm(true)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Outlined.LocationOn,
                                contentDescription = "Location",
                                modifier = Modifier.size(18.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = state.location.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Text(
                            text = state.currentTime.format(dateFormatter),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(
                            imageVector = Icons.Outlined.Settings,
                            contentDescription = "Location & Alarm Settings"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Hero Countdown & Solar Arc Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.verticalGradient(gradientColors))
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val countdown = state.countdown
                    val label = when (countdown?.nextEvent) {
                        SolarEventType.SUNRISE -> "TIME REMAINING TO SUNRISE"
                        SolarEventType.SUNSET -> "TIME REMAINING TO SUNSET"
                        null -> if (state.solarTimes.isPolarDay) "POLAR DAY (24H SUNLIGHT)" else "POLAR NIGHT"
                    }

                    Text(
                        text = label,
                        color = Color.White.copy(alpha = 0.85f),
                        style = MaterialTheme.typography.labelLarge,
                        letterSpacing = 1.2.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = countdown?.formattedHms() ?: "--:--:--",
                        color = Color.White,
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    if (countdown != null) {
                        val eventName = if (countdown.nextEvent == SolarEventType.SUNRISE) "Sunrise" else "Sunset"
                        val isTomorrow = countdown.targetTime.toLocalDate().isAfter(state.currentTime.toLocalDate())
                        val dayTag = if (isTomorrow) " tomorrow" else " today"
                        Text(
                            text = "$eventName at ${countdown.targetTime.format(timeFormatter)}$dayTag",
                            color = Color.White.copy(alpha = 0.90f),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    SolarArcCanvas(daylightProgress = state.daylightProgress)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Sunrise ${formatTimeOrDash(state.solarTimes.sunrise, timeFormatter)}",
                            color = Color.White.copy(alpha = 0.85f),
                            style = MaterialTheme.typography.labelMedium
                        )
                        Text(
                            text = "Sunset ${formatTimeOrDash(state.solarTimes.sunset, timeFormatter)}",
                            color = Color.White.copy(alpha = 0.85f),
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }

            // Primary Sunrise & Sunset Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SolarStatCard(
                    title = "Sunrise",
                    value = formatTimeOrDash(state.solarTimes.sunrise, timeFormatter),
                    subtitle = "Dawn ${formatTimeOrDash(state.solarTimes.civilDawn, timeFormatter)}",
                    icon = Icons.Outlined.WbTwilight,
                    accentColor = Color(0xFFFB8C00),
                    modifier = Modifier.weight(1f)
                )
                SolarStatCard(
                    title = "Sunset",
                    value = formatTimeOrDash(state.solarTimes.sunset, timeFormatter),
                    subtitle = "Dusk ${formatTimeOrDash(state.solarTimes.civilDusk, timeFormatter)}",
                    icon = Icons.Outlined.NightsStay,
                    accentColor = Color(0xFF5E35B1),
                    modifier = Modifier.weight(1f)
                )
            }

            // Secondary Solar Details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SolarStatCard(
                    title = "Solar Noon",
                    value = state.solarTimes.solarNoon.format(timeFormatter),
                    subtitle = "Sun at peak",
                    icon = Icons.Outlined.WbSunny,
                    accentColor = Color(0xFFF9A825),
                    modifier = Modifier.weight(1f)
                )
                SolarStatCard(
                    title = "Daylight",
                    value = formatDuration(state.solarTimes.daylightDuration),
                    subtitle = state.location.zoneId,
                    icon = Icons.Outlined.Schedule,
                    accentColor = Color(0xFF00897B),
                    modifier = Modifier.weight(1f)
                )
            }

            // Native Pre-Event Alarm Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                imageVector = Icons.Outlined.Alarm,
                                contentDescription = "Alarm",
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                val next = state.nextAlarm
                                val alarmTitle = if (state.alarmConfig.enabled && next != null) {
                                    "Alarm Armed • ${next.triggerTime.format(timeFormatter)}"
                                } else if (state.alarmConfig.enabled) {
                                    "Alarm Armed"
                                } else {
                                    "Pre-Event Alarm Off"
                                }
                                val alarmSub = if (state.alarmConfig.enabled && next != null) {
                                    val ev = if (next.eventType == SolarEventType.SUNRISE) "Sunrise" else "Sunset"
                                    "${state.alarmConfig.leadMinutes} min before $ev"
                                } else {
                                    "Alert ${state.alarmConfig.leadMinutes} min before sunrise or sunset"
                                }
                                Text(text = alarmTitle, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Text(
                                    text = alarmSub,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                )
                            }
                        }
                        Switch(
                            checked = state.alarmConfig.enabled,
                            onCheckedChange = { enabled ->
                                if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    onToggleAlarm(enabled)
                                }
                            }
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = onTestAlarm) {
                            Text("Test Alarm")
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        OutlinedButton(onClick = onOpenSettings) {
                            Text("Configure")
                        }
                    }
                }
            }

            // Location Coordinates Footer
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Coordinates",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                        Text(
                            text = state.location.formattedCoordinates(),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Text(
                        text = "Local ${state.currentTime.format(timeFormatter)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
private fun SolarStatCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }
    }
}

private fun formatTimeOrDash(time: ZonedDateTime?, formatter: DateTimeFormatter): String =
    time?.format(formatter) ?: "--:--"

private fun formatDuration(duration: Duration?): String {
    if (duration == null) return "--"
    val hours = duration.toHours()
    val minutes = (duration.toMinutes() % 60)
    return "${hours}h ${minutes}m"
}

private fun phaseGradient(phase: DayPhase): List<Color> = when (phase) {
    DayPhase.DAWN -> listOf(Color(0xFF3949AB), Color(0xFFEC407A), Color(0xFFFFA726))
    DayPhase.MORNING -> listOf(Color(0xFF1565C0), Color(0xFF42A5F5))
    DayPhase.AFTERNOON -> listOf(Color(0xFF0277BD), Color(0xFF29B6F6))
    DayPhase.GOLDEN_HOUR -> listOf(Color(0xFF5D4037), Color(0xFFE65100), Color(0xFFFFB300))
    DayPhase.DUSK -> listOf(Color(0xFF1A237E), Color(0xFF6A1B9A), Color(0xFFD84315))
    DayPhase.NIGHT -> listOf(Color(0xFF0B1026), Color(0xFF1C2B4B))
}
