package com.sunrisesunset.app.alarm

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Offline synthesized musical chime player for exact-time Sunrise & Sunset alerts.
 * Uses Android AudioTrack so zero external audio files are required.
 */
object SolarChimePlayer {

    private const val SAMPLE_RATE = 22050

    fun playSunriseTune() {
        // Bright ascending dawn arpeggio: C5 -> E5 -> G5 -> B5 -> C6
        val notes = listOf(
            523.25 to 260,
            659.25 to 260,
            783.99 to 280,
            987.77 to 320,
            1046.50 to 650
        )
        playMelodyAsync(notes)
    }

    fun playSunsetTune() {
        // Warm descending twilight cadence: A5 -> G5 -> E5 -> D5 -> C5
        val notes = listOf(
            880.00 to 280,
            783.99 to 280,
            659.25 to 300,
            587.33 to 320,
            523.25 to 700
        )
        playMelodyAsync(notes)
    }

    private fun playMelodyAsync(notes: List<Pair<Double, Int>>) {
        thread(start = true, isDaemon = true, name = "SolarChimePlayer") {
            runCatching {
                val totalSamples = notes.sumOf { (_, ms) -> (SAMPLE_RATE * ms) / 1000 }
                val pcm = ShortArray(totalSamples)
                var offset = 0

                for ((freq, durationMs) in notes) {
                    val count = (SAMPLE_RATE * durationMs) / 1000
                    for (i in 0 until count) {
                        val t = i.toDouble() / SAMPLE_RATE
                        val env = (if (i < 400) i / 400.0 else 1.0) * exp(-3.2 * t)
                        val wave = 0.78 * sin(2.0 * PI * freq * t) + 0.22 * sin(2.0 * PI * freq * 2.0 * t)
                        val sample = (wave * env * Short.MAX_VALUE * 0.65).toInt()
                            .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                        if (offset < pcm.size) {
                            pcm[offset++] = sample.toShort()
                        }
                    }
                }

                val bufferBytes = pcm.size * 2
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SAMPLE_RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .setBufferSizeInBytes(bufferBytes)
                    .build()

                track.write(pcm, 0, pcm.size)
                track.play()
                val totalMs = notes.sumOf { it.second }.toLong()
                Thread.sleep(totalMs + 250L)
                track.stop()
                track.release()
            }
        }
    }
}
