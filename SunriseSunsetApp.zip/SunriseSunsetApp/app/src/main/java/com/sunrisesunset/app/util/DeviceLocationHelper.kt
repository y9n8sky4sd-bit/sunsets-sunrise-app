package com.sunrisesunset.app.util

import android.annotation.SuppressLint
import android.content.Context
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import com.sunrisesunset.app.model.LocationConfig
import java.time.ZoneId
import java.util.Locale

object DeviceLocationHelper {

    @SuppressLint("MissingPermission")
    fun getLastKnownLocation(context: Context): LocationConfig? {
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
        val providers = listOf(
            LocationManager.GPS_PROVIDER,
            LocationManager.NETWORK_PROVIDER,
            LocationManager.PASSIVE_PROVIDER
        )

        var bestLocation: Location? = null
        for (provider in providers) {
            val loc = runCatching { manager.getLastKnownLocation(provider) }.getOrNull() ?: continue
            if (bestLocation == null || loc.accuracy < bestLocation.accuracy) {
                bestLocation = loc
            }
        }

        val resolved = bestLocation ?: return null
        val cityName = resolveLocationName(context, resolved.latitude, resolved.longitude)
        return LocationConfig(
            name = cityName,
            latitude = resolved.latitude,
            longitude = resolved.longitude,
            zoneId = ZoneId.systemDefault().id
        )
    }

    @Suppress("DEPRECATION")
    private fun resolveLocationName(context: Context, lat: Double, lon: Double): String {
        return runCatching {
            val geocoder = Geocoder(context, Locale.getDefault())
            val addresses = geocoder.getFromLocation(lat, lon, 1)
            val first = addresses?.firstOrNull()
            val locality = first?.locality ?: first?.subAdminArea ?: first?.adminArea
            val country = first?.countryName
            when {
                !locality.isNullOrBlank() && !country.isNullOrBlank() -> "$locality, $country"
                !locality.isNullOrBlank() -> locality
                else -> "Current Location"
            }
        }.getOrElse { "Current Location" }
    }
}
