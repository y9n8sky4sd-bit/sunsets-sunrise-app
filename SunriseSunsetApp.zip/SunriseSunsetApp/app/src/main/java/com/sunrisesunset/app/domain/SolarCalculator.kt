package com.sunrisesunset.app.domain

import com.sunrisesunset.app.model.AlarmConfig
import com.sunrisesunset.app.model.AlarmTarget
import com.sunrisesunset.app.model.DailySolarTimes
import com.sunrisesunset.app.model.DayPhase
import com.sunrisesunset.app.model.LocationConfig
import com.sunrisesunset.app.model.ScheduledSolarAlarm
import com.sunrisesunset.app.model.SolarCountdown
import com.sunrisesunset.app.model.SolarEventType
import java.time.Duration
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToLong
import kotlin.math.sin
import kotlin.math.tan

object SolarCalculator {

    private const val OFFICIAL_ZENITH_DEG = 90.833
    private const val CIVIL_TWILIGHT_ZENITH_DEG = 96.0

    fun calculateForDate(
        date: LocalDate,
        latitude: Double,
        longitude: Double,
        zoneId: ZoneId
    ): DailySolarTimes {
        val midnight = date.atStartOfDay(zoneId)
        val tzOffsetHours = midnight.offset.totalSeconds / 3600.0

        val noonUtcOffsetDays = (12.0 - tzOffsetHours) / 24.0
        val jd = toJulianDay(date) + noonUtcOffsetDays
        val jc = (jd - 2451545.0) / 36525.0

        val geomMeanLongSun = (280.46646 + jc * (36000.76983 + jc * 0.0003032)) % 360.0
        val geomMeanAnomSun = 357.52911 + jc * (35999.05029 - 0.0001537 * jc)
        val eccentEarthOrbit = 0.016708634 - jc * (0.000042037 + 0.0000001267 * jc)

        val anomRad = Math.toRadians(geomMeanAnomSun)
        val sunEqOfCtr = sin(anomRad) * (1.914602 - jc * (0.004817 + 0.000014 * jc)) +
            sin(2.0 * anomRad) * (0.019993 - 0.000101 * jc) +
            sin(3.0 * anomRad) * 0.000289

        val sunTrueLong = geomMeanLongSun + sunEqOfCtr
        val omega = 125.04 - 1934.136 * jc
        val sunAppLong = sunTrueLong - 0.00569 - 0.00478 * sin(Math.toRadians(omega))

        val meanObliqEcliptic = 23.0 + (26.0 + ((21.448 - jc * (46.815 + jc * (0.00059 - jc * 0.001813)))) / 60.0) / 60.0
        val obliqCorr = meanObliqEcliptic + 0.00256 * cos(Math.toRadians(omega))

        val sunDeclinRad = asin(sin(Math.toRadians(obliqCorr)) * sin(Math.toRadians(sunAppLong)))

        val y = tan(Math.toRadians(obliqCorr / 2.0)).let { it * it }
        val meanLongRad = Math.toRadians(geomMeanLongSun)
        val eqOfTimeMin = 4.0 * Math.toDegrees(
            y * sin(2.0 * meanLongRad) -
                2.0 * eccentEarthOrbit * sin(anomRad) +
                4.0 * eccentEarthOrbit * y * sin(anomRad) * cos(2.0 * meanLongRad) -
                0.5 * y * y * sin(4.0 * meanLongRad) -
                1.25 * eccentEarthOrbit * eccentEarthOrbit * sin(2.0 * anomRad)
        )

        val solarNoonMin = 720.0 - 4.0 * longitude - eqOfTimeMin + tzOffsetHours * 60.0
        val solarNoon = minutesToZonedDateTime(midnight, solarNoonMin)

        val officialCosHa = computeCosHourAngle(latitude, sunDeclinRad, OFFICIAL_ZENITH_DEG)
        val isPolarDay = officialCosHa < -1.0
        val isPolarNight = officialCosHa > 1.0

        val sunrise: ZonedDateTime?
        val sunset: ZonedDateTime?
        val daylightDuration: Duration?

        if (isPolarDay || isPolarNight) {
            sunrise = null
            sunset = null
            daylightDuration = if (isPolarDay) Duration.ofHours(24) else Duration.ZERO
        } else {
            val haDeg = Math.toDegrees(acos(officialCosHa))
            val sunriseMin = solarNoonMin - haDeg * 4.0
            val sunsetMin = solarNoonMin + haDeg * 4.0
            sunrise = minutesToZonedDateTime(midnight, sunriseMin)
            sunset = minutesToZonedDateTime(midnight, sunsetMin)
            daylightDuration = Duration.between(sunrise, sunset)
        }

        val civilCosHa = computeCosHourAngle(latitude, sunDeclinRad, CIVIL_TWILIGHT_ZENITH_DEG)
        val civilDawn: ZonedDateTime?
        val civilDusk: ZonedDateTime?
        if (civilCosHa in -1.0..1.0) {
            val civilHaDeg = Math.toDegrees(acos(civilCosHa))
            civilDawn = minutesToZonedDateTime(midnight, solarNoonMin - civilHaDeg * 4.0)
            civilDusk = minutesToZonedDateTime(midnight, solarNoonMin + civilHaDeg * 4.0)
        } else {
            civilDawn = null
            civilDusk = null
        }

        return DailySolarTimes(
            sunrise = sunrise,
            sunset = sunset,
            solarNoon = solarNoon,
            civilDawn = civilDawn,
            civilDusk = civilDusk,
            daylightDuration = daylightDuration,
            isPolarDay = isPolarDay,
            isPolarNight = isPolarNight
        )
    }

    fun calculateCountdown(
        now: ZonedDateTime,
        location: LocationConfig
    ): SolarCountdown? {
        val zone = location.safeZoneId()
        val localNow = now.withZoneSameInstant(zone)
        val today = calculateForDate(localNow.toLocalDate(), location.latitude, location.longitude, zone)

        val todaySunrise = today.sunrise
        val todaySunset = today.sunset

        if (todaySunrise != null && localNow.isBefore(todaySunrise)) {
            return SolarCountdown(
                nextEvent = SolarEventType.SUNRISE,
                targetTime = todaySunrise,
                remaining = Duration.between(localNow, todaySunrise).coerceAtLeast(Duration.ZERO)
            )
        }

        if (todaySunset != null && localNow.isBefore(todaySunset)) {
            return SolarCountdown(
                nextEvent = SolarEventType.SUNSET,
                targetTime = todaySunset,
                remaining = Duration.between(localNow, todaySunset).coerceAtLeast(Duration.ZERO)
            )
        }

        val tomorrow = calculateForDate(
            localNow.toLocalDate().plusDays(1),
            location.latitude,
            location.longitude,
            zone
        )
        val tomorrowSunrise = tomorrow.sunrise ?: return null
        return SolarCountdown(
            nextEvent = SolarEventType.SUNRISE,
            targetTime = tomorrowSunrise,
            remaining = Duration.between(localNow, tomorrowSunrise).coerceAtLeast(Duration.ZERO)
        )
    }

    fun calculateNextAlarm(
        now: ZonedDateTime,
        location: LocationConfig,
        alarmConfig: AlarmConfig
    ): ScheduledSolarAlarm? {
        val zone = location.safeZoneId()
        val localNow = now.withZoneSameInstant(zone)
        val lead = alarmConfig.leadMinutes.coerceIn(1, 120).toLong()
        val candidates = mutableListOf<ScheduledSolarAlarm>()

        fun addDay(dayOffset: Long) {
            val times = calculateForDate(
                localNow.toLocalDate().plusDays(dayOffset),
                location.latitude,
                location.longitude,
                zone
            )
            if (alarmConfig.target == AlarmTarget.BOTH || alarmConfig.target == AlarmTarget.SUNRISE) {
                times.sunrise?.let { sr ->
                    candidates.add(ScheduledSolarAlarm(SolarEventType.SUNRISE, sr, sr.minusMinutes(lead)))
                }
            }
            if (alarmConfig.target == AlarmTarget.BOTH || alarmConfig.target == AlarmTarget.SUNSET) {
                times.sunset?.let { ss ->
                    candidates.add(ScheduledSolarAlarm(SolarEventType.SUNSET, ss, ss.minusMinutes(lead)))
                }
            }
        }

        addDay(0)
        addDay(1)
        return candidates
            .sortedBy { it.triggerTime }
            .firstOrNull { it.triggerTime.isAfter(localNow) }
    }

    fun calculateDaylightProgress(now: ZonedDateTime, times: DailySolarTimes): Float? {
        val sunrise = times.sunrise ?: return if (times.isPolarDay) 0.5f else null
        val sunset = times.sunset ?: return null
        val totalSeconds = Duration.between(sunrise, sunset).seconds
        if (totalSeconds <= 0L) return null
        val elapsedSeconds = Duration.between(sunrise, now).seconds
        if (elapsedSeconds < 0L || elapsedSeconds > totalSeconds) return null
        return (elapsedSeconds.toFloat() / totalSeconds.toFloat()).coerceIn(0f, 1f)
    }

    fun determineDayPhase(now: ZonedDateTime, times: DailySolarTimes): DayPhase {
        val sunrise = times.sunrise
        val sunset = times.sunset
        if (times.isPolarDay) return DayPhase.AFTERNOON
        if (times.isPolarNight || sunrise == null || sunset == null) return DayPhase.NIGHT

        val dawnStart = times.civilDawn ?: sunrise.minusMinutes(30)
        val duskEnd = times.civilDusk ?: sunset.plusMinutes(30)
        val goldenStart = sunset.minusMinutes(45)

        return when {
            now.isBefore(dawnStart) -> DayPhase.NIGHT
            now.isBefore(sunrise) -> DayPhase.DAWN
            now.isBefore(times.solarNoon) -> DayPhase.MORNING
            now.isBefore(goldenStart) -> DayPhase.AFTERNOON
            now.isBefore(sunset) -> DayPhase.GOLDEN_HOUR
            now.isBefore(duskEnd) -> DayPhase.DUSK
            else -> DayPhase.NIGHT
        }
    }

    private fun computeCosHourAngle(latitudeDeg: Double, sunDeclinRad: Double, zenithDeg: Double): Double {
        val latRad = Math.toRadians(latitudeDeg)
        val zenithRad = Math.toRadians(zenithDeg)
        return (cos(zenithRad) / (cos(latRad) * cos(sunDeclinRad))) - tan(latRad) * tan(sunDeclinRad)
    }

    private fun minutesToZonedDateTime(midnight: ZonedDateTime, minutesFromMidnight: Double): ZonedDateTime {
        val secondsFromMidnight = (minutesFromMidnight * 60.0).roundToLong()
        return midnight.plusSeconds(secondsFromMidnight)
    }

    private fun toJulianDay(date: LocalDate): Double {
        var year = date.year
        var month = date.monthValue
        val day = date.dayOfMonth
        if (month <= 2) {
            year -= 1
            month += 12
        }
        val a = floor(year / 100.0)
        val b = 2.0 - a + floor(a / 4.0)
        return floor(365.25 * (year + 4716)) + floor(30.6001 * (month + 1)) + day + b - 1524.5
    }
}
