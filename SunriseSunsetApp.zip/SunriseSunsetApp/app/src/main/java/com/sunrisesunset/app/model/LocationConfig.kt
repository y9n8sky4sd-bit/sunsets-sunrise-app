package com.sunrisesunset.app.model

import java.time.ZoneId

data class LocationConfig(
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val zoneId: String
) {
    fun safeZoneId(): ZoneId = runCatching { ZoneId.of(zoneId) }.getOrElse { ZoneId.systemDefault() }

    fun formattedCoordinates(): String {
        val latDir = if (latitude >= 0) "N" else "S"
        val lonDir = if (longitude >= 0) "E" else "W"
        return String.format("%.4f° %s, %.4f° %s", kotlin.math.abs(latitude), latDir, kotlin.math.abs(longitude), lonDir)
    }
}
