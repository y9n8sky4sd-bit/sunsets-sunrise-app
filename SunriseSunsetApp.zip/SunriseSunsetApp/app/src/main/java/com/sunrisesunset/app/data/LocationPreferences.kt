package com.sunrisesunset.app.data

import android.content.Context
import com.sunrisesunset.app.model.AlarmConfig
import com.sunrisesunset.app.model.AlarmTarget
import com.sunrisesunset.app.model.LocationConfig

class LocationPreferences(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadLocation(): LocationConfig {
        val default = PresetCities.defaultLocation
        val name = prefs.getString(KEY_NAME, default.name) ?: default.name
        val lat = prefs.getString(KEY_LAT, null)?.toDoubleOrNull() ?: default.latitude
        val lon = prefs.getString(KEY_LON, null)?.toDoubleOrNull() ?: default.longitude
        val zoneId = prefs.getString(KEY_ZONE_ID, default.zoneId) ?: default.zoneId
        return LocationConfig(name = name, latitude = lat, longitude = lon, zoneId = zoneId)
    }

    fun saveLocation(config: LocationConfig) {
        prefs.edit()
            .putString(KEY_NAME, config.name)
            .putString(KEY_LAT, config.latitude.toString())
            .putString(KEY_LON, config.longitude.toString())
            .putString(KEY_ZONE_ID, config.zoneId)
            .apply()
    }

    fun loadUse24HourFormat(): Boolean = prefs.getBoolean(KEY_USE_24H, false)

    fun saveUse24HourFormat(use24Hour: Boolean) {
        prefs.edit().putBoolean(KEY_USE_24H, use24Hour).apply()
    }

    fun loadAlarmConfig(): AlarmConfig {
        val enabled = prefs.getBoolean(KEY_ALARM_ENABLED, false)
        val lead = prefs.getInt(KEY_ALARM_LEAD, 10).coerceIn(1, 120)
        val targetName = prefs.getString(KEY_ALARM_TARGET, AlarmTarget.BOTH.name) ?: AlarmTarget.BOTH.name
        val target = runCatching { AlarmTarget.valueOf(targetName) }.getOrDefault(AlarmTarget.BOTH)
        val exactChime = prefs.getBoolean(KEY_EXACT_CHIME, true)
        return AlarmConfig(enabled = enabled, leadMinutes = lead, target = target, exactChimeEnabled = exactChime)
    }

    fun saveAlarmConfig(config: AlarmConfig) {
        prefs.edit()
            .putBoolean(KEY_ALARM_ENABLED, config.enabled)
            .putInt(KEY_ALARM_LEAD, config.leadMinutes.coerceIn(1, 120))
            .putString(KEY_ALARM_TARGET, config.target.name)
            .putBoolean(KEY_EXACT_CHIME, config.exactChimeEnabled)
            .apply()
    }

    companion object {
        private const val PREFS_NAME = "solar_time_prefs"
        private const val KEY_NAME = "location_name"
        private const val KEY_LAT = "location_lat"
        private const val KEY_LON = "location_lon"
        private const val KEY_ZONE_ID = "location_zone_id"
        private const val KEY_USE_24H = "use_24_hour_format"
        private const val KEY_ALARM_ENABLED = "alarm_enabled"
        private const val KEY_ALARM_LEAD = "alarm_lead_minutes"
        private const val KEY_ALARM_TARGET = "alarm_target"
        private const val KEY_EXACT_CHIME = "exact_chime_enabled"
    }
}
