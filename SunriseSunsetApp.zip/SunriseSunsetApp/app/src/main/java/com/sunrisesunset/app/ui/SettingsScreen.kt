package com.sunrisesunset.app.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.MyLocation
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.sunrisesunset.app.alarm.SolarChimePlayer
import com.sunrisesunset.app.data.PresetCities
import com.sunrisesunset.app.model.AlarmConfig
import com.sunrisesunset.app.model.AlarmTarget
import com.sunrisesunset.app.model.LocationConfig
import com.sunrisesunset.app.util.DeviceLocationHelper
import java.time.ZoneId

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    currentLocation: LocationConfig,
    use24HourFormat: Boolean,
    alarmConfig: AlarmConfig,
    onSaveLocation: (LocationConfig) -> Unit,
    onToggle24Hour: (Boolean) -> Unit,
    onUpdateAlarm: (AlarmConfig) -> Unit,
    onTestAlarm: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current

    var searchQuery by remember { mutableStateOf("") }
    var customName by remember(currentLocation) { mutableStateOf(currentLocation.name) }
    var customLat by remember(currentLocation) { mutableStateOf(currentLocation.latitude.toString()) }
    var customLon by remember(currentLocation) { mutableStateOf(currentLocation.longitude.toString()) }
    var customZone by remember(currentLocation) { mutableStateOf(currentLocation.zoneId) }
    var leadInput by remember(alarmConfig.leadMinutes) { mutableStateOf(alarmConfig.leadMinutes.toString()) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val granted = grants[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            val gpsLocation = DeviceLocationHelper.getLastKnownLocation(context)
            if (gpsLocation != null) {
                onSaveLocation(gpsLocation)
                statusMessage = "Updated to GPS location: ${gpsLocation.name}"
                isError = false
            } else {
                statusMessage = "Unable to read a cached GPS fix. Ensure Location is enabled or choose a city below."
                isError = true
            }
        } else {
            statusMessage = "Location permission denied. You can still pick a city or enter coordinates."
            isError = true
        }
    }

    val notifPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        onUpdateAlarm(alarmConfig.copy(enabled = true))
    }

    val filteredCities = remember(searchQuery) {
        if (searchQuery.isBlank()) {
            PresetCities.all
        } else {
            PresetCities.all.filter {
                it.name.contains(searchQuery.trim(), ignoreCase = true) ||
                    it.zoneId.contains(searchQuery.trim(), ignoreCase = true)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Location & Alarm Settings") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (statusMessage != null) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isError) {
                            MaterialTheme.colorScheme.errorContainer
                        } else {
                            MaterialTheme.colorScheme.primaryContainer
                        }
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = statusMessage!!,
                        modifier = Modifier.padding(12.dp),
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (isError) {
                            MaterialTheme.colorScheme.onErrorContainer
                        } else {
                            MaterialTheme.colorScheme.onPrimaryContainer
                        }
                    )
                }
            }

            // Native Alarm Settings Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Sunrise & Sunset Alarm",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Rings & vibrates even when app is closed",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                        }
                        Switch(
                            checked = alarmConfig.enabled,
                            onCheckedChange = { enabled ->
                                if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    onUpdateAlarm(alarmConfig.copy(enabled = enabled))
                                }
                            }
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            AlarmTarget.BOTH to "Both",
                            AlarmTarget.SUNRISE to "Sunrise",
                            AlarmTarget.SUNSET to "Sunset"
                        ).forEach { (target, label) ->
                            FilterChip(
                                selected = alarmConfig.target == target,
                                onClick = { onUpdateAlarm(alarmConfig.copy(target = target)) },
                                label = { Text(label) }
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(5, 10, 15, 30).forEach { mins ->
                            FilterChip(
                                selected = alarmConfig.leadMinutes == mins,
                                onClick = {
                                    leadInput = mins.toString()
                                    onUpdateAlarm(alarmConfig.copy(leadMinutes = mins))
                                },
                                label = { Text("${mins}m") }
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = leadInput,
                            onValueChange = { leadInput = it },
                            label = { Text("Minutes Before (1–120)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(onClick = {
                            val mins = leadInput.trim().toIntOrNull()
                            if (mins == null || mins !in 1..120) {
                                statusMessage = "Enter a lead time between 1 and 120 minutes."
                                isError = true
                            } else {
                                onUpdateAlarm(alarmConfig.copy(leadMinutes = mins))
                                statusMessage = "Alarm set to $mins minutes before event."
                                isError = false
                            }
                        }) {
                            Text("Set")
                        }
                    }

                    OutlinedButton(
                        onClick = onTestAlarm,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Send Test Alarm Notification")
                    }

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Exact-Time Chime Tune",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Play melody at the exact sunrise & sunset moment",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                        }
                        Switch(
                            checked = alarmConfig.exactChimeEnabled,
                            onCheckedChange = { enabled ->
                                onUpdateAlarm(alarmConfig.copy(exactChimeEnabled = enabled))
                            }
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { SolarChimePlayer.playSunriseTune() },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Sunrise Tune")
                        }
                        OutlinedButton(
                            onClick = { SolarChimePlayer.playSunsetTune() },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Sunset Tune")
                        }
                    }
                }
            }

            // GPS Button
            OutlinedButton(
                onClick = {
                    permissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.ACCESS_COARSE_LOCATION,
                            Manifest.permission.ACCESS_FINE_LOCATION
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(imageVector = Icons.Outlined.MyLocation, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Use Current GPS Location")
            }

            // Display Preference
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "24-Hour Time Format",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Display times as 17:49 instead of 05:49 PM",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                        )
                    }
                    Switch(
                        checked = use24HourFormat,
                        onCheckedChange = onToggle24Hour
                    )
                }
            }

            // Custom Location Entry
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Custom Location",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )

                    OutlinedTextField(
                        value = customName,
                        onValueChange = { customName = it },
                        label = { Text("Location Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = customLat,
                            onValueChange = { customLat = it },
                            label = { Text("Latitude") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = customLon,
                            onValueChange = { customLon = it },
                            label = { Text("Longitude") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = customZone,
                        onValueChange = { customZone = it },
                        label = { Text("IANA Timezone (e.g. Asia/Kolkata)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            val lat = customLat.trim().toDoubleOrNull()
                            val lon = customLon.trim().toDoubleOrNull()
                            val validZone = runCatching { ZoneId.of(customZone.trim()) }.isSuccess

                            when {
                                customName.isBlank() -> {
                                    statusMessage = "Please enter a location name."
                                    isError = true
                                }
                                lat == null || lat !in -90.0..90.0 -> {
                                    statusMessage = "Latitude must be between -90 and 90."
                                    isError = true
                                }
                                lon == null || lon !in -180.0..180.0 -> {
                                    statusMessage = "Longitude must be between -180 and 180."
                                    isError = true
                                }
                                !validZone -> {
                                    statusMessage = "Invalid timezone ID. Example: Asia/Kolkata or America/New_York."
                                    isError = true
                                }
                                else -> {
                                    onSaveLocation(
                                        LocationConfig(
                                            name = customName.trim(),
                                            latitude = lat,
                                            longitude = lon,
                                            zoneId = customZone.trim()
                                        )
                                    )
                                    statusMessage = "Saved custom location: ${customName.trim()}"
                                    isError = false
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Save Custom Location")
                    }
                }
            }

            // Preset Cities List
            Text(
                text = "Preset Cities",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search city or timezone...") },
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column {
                    filteredCities.forEachIndexed { index, city ->
                        val isSelected = city.name == currentLocation.name &&
                            kotlin.math.abs(city.latitude - currentLocation.latitude) < 0.001
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSaveLocation(city)
                                    onNavigateBack()
                                }
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = city.name,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                                Text(
                                    text = "${city.formattedCoordinates()} • ${city.zoneId}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Outlined.CheckCircle,
                                    contentDescription = "Selected",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                        if (index < filteredCities.lastIndex) {
                            HorizontalDivider()
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
