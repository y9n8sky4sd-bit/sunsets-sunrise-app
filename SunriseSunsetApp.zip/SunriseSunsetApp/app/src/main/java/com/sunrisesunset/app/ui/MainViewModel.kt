package com.sunrisesunset.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sunrisesunset.app.alarm.AlarmScheduler
import com.sunrisesunset.app.data.LocationPreferences
import com.sunrisesunset.app.domain.SolarCalculator
import com.sunrisesunset.app.model.AlarmConfig
import com.sunrisesunset.app.model.DailySolarTimes
import com.sunrisesunset.app.model.DayPhase
import com.sunrisesunset.app.model.LocationConfig
import com.sunrisesunset.app.model.ScheduledSolarAlarm
import com.sunrisesunset.app.model.SolarCountdown
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.time.ZonedDateTime

data class SolarUiState(
    val location: LocationConfig,
    val use24HourFormat: Boolean,
    val alarmConfig: AlarmConfig,
    val nextAlarm: ScheduledSolarAlarm?,
    val currentTime: ZonedDateTime,
    val solarTimes: DailySolarTimes,
    val countdown: SolarCountdown?,
    val daylightProgress: Float?,
    val dayPhase: DayPhase
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val prefs = LocationPreferences(appContext)

    private val _uiState = MutableStateFlow(
        buildState(
            location = prefs.loadLocation(),
            use24Hour = prefs.loadUse24HourFormat(),
            alarmConfig = prefs.loadAlarmConfig()
        )
    )
    val uiState: StateFlow<SolarUiState> = _uiState.asStateFlow()

    init {
        val current = _uiState.value
        AlarmScheduler.syncAlarm(appContext, current.location, current.alarmConfig, current.use24HourFormat)
        startLiveClock()
    }

    private fun startLiveClock() {
        viewModelScope.launch {
            while (isActive) {
                refreshNow()
                delay(1_000L)
            }
        }
    }

    fun updateLocation(newLocation: LocationConfig) {
        prefs.saveLocation(newLocation)
        _uiState.update { current ->
            AlarmScheduler.syncAlarm(appContext, newLocation, current.alarmConfig, current.use24HourFormat)
            buildState(newLocation, current.use24HourFormat, current.alarmConfig)
        }
    }

    fun updateTimeFormat(use24Hour: Boolean) {
        prefs.saveUse24HourFormat(use24Hour)
        _uiState.update { current ->
            AlarmScheduler.syncAlarm(appContext, current.location, current.alarmConfig, use24Hour)
            current.copy(use24HourFormat = use24Hour)
        }
    }

    fun updateAlarmConfig(newAlarmConfig: AlarmConfig) {
        prefs.saveAlarmConfig(newAlarmConfig)
        _uiState.update { current ->
            AlarmScheduler.syncAlarm(appContext, current.location, newAlarmConfig, current.use24HourFormat)
            buildState(current.location, current.use24HourFormat, newAlarmConfig)
        }
    }

    fun sendTestAlarm() {
        val current = _uiState.value
        AlarmScheduler.sendTestAlarm(appContext, current.location, current.alarmConfig.leadMinutes)
    }

    private fun refreshNow() {
        _uiState.update { current ->
            buildState(current.location, current.use24HourFormat, current.alarmConfig)
        }
    }

    private fun buildState(
        location: LocationConfig,
        use24Hour: Boolean,
        alarmConfig: AlarmConfig
    ): SolarUiState {
        val zone = location.safeZoneId()
        val now = ZonedDateTime.now(zone)
        val solarTimes = SolarCalculator.calculateForDate(
            date = now.toLocalDate(),
            latitude = location.latitude,
            longitude = location.longitude,
            zoneId = zone
        )
        val countdown = SolarCalculator.calculateCountdown(now, location)
        val progress = SolarCalculator.calculateDaylightProgress(now, solarTimes)
        val phase = SolarCalculator.determineDayPhase(now, solarTimes)
        val nextAlarm = if (alarmConfig.enabled) {
            SolarCalculator.calculateNextAlarm(now, location, alarmConfig)
        } else {
            null
        }

        return SolarUiState(
            location = location,
            use24HourFormat = use24Hour,
            alarmConfig = alarmConfig,
            nextAlarm = nextAlarm,
            currentTime = now,
            solarTimes = solarTimes,
            countdown = countdown,
            daylightProgress = progress,
            dayPhase = phase
        )
    }
}
