package com.sunrisesunset.app.data

import com.sunrisesunset.app.model.LocationConfig

object PresetCities {
    val defaultLocation = LocationConfig(
        name = "Chalisgaon, India",
        latitude = 20.4640,
        longitude = 75.0061,
        zoneId = "Asia/Kolkata"
    )

    val all: List<LocationConfig> = listOf(
        defaultLocation,
        LocationConfig("Mumbai, India", 19.0760, 72.8777, "Asia/Kolkata"),
        LocationConfig("Pune, India", 18.5204, 73.8567, "Asia/Kolkata"),
        LocationConfig("New Delhi, India", 28.6139, 77.2090, "Asia/Kolkata"),
        LocationConfig("Bengaluru, India", 12.9716, 77.5946, "Asia/Kolkata"),
        LocationConfig("Hyderabad, India", 17.3850, 78.4867, "Asia/Kolkata"),
        LocationConfig("Chennai, India", 13.0827, 80.2707, "Asia/Kolkata"),
        LocationConfig("Kolkata, India", 22.5726, 88.3639, "Asia/Kolkata"),
        LocationConfig("Dubai, UAE", 25.2048, 55.2708, "Asia/Dubai"),
        LocationConfig("Singapore", 1.3521, 103.8198, "Asia/Singapore"),
        LocationConfig("Tokyo, Japan", 35.6762, 139.6503, "Asia/Tokyo"),
        LocationConfig("Sydney, Australia", -33.8688, 151.2093, "Australia/Sydney"),
        LocationConfig("London, UK", 51.5074, -0.1278, "Europe/London"),
        LocationConfig("Paris, France", 48.8566, 2.3522, "Europe/Paris"),
        LocationConfig("Berlin, Germany", 52.5200, 13.4050, "Europe/Berlin"),
        LocationConfig("New York, USA", 40.7128, -74.0060, "America/New_York"),
        LocationConfig("San Francisco, USA", 37.7749, -122.4194, "America/Los_Angeles"),
        LocationConfig("Chicago, USA", 41.8781, -87.6298, "America/Chicago"),
        LocationConfig("Toronto, Canada", 43.6532, -79.3832, "America/Toronto"),
        LocationConfig("Cape Town, South Africa", -33.9249, 18.4241, "Africa/Johannesburg"),
        LocationConfig("Reykjavik, Iceland", 64.1466, -21.9426, "Atlantic/Reykjavik")
    )
}
